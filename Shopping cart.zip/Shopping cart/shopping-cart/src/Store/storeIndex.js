import { createStore } from 'redux';
import rootMiddleware from './middlewares/middlewareIndex';
import rootReducer from '../Reducers/reducerIndex';

const store = createStore(
  rootReducer,
  rootMiddleware
);

export default store;