import cartApi from '../Products/services/cartApi';

function removeCart(cartItem) {
    return function(dispatch){
        cartApi
            .remove(cartItem)
            .then(() => {
                const action = { type: "REMOVE_CART", payload: cartItem };
                dispatch(action);
            })
        
    }
}

export default removeCart;