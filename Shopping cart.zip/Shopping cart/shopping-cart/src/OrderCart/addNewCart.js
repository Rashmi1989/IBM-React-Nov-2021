import cartApi from '../Products/services/cartApi';

function addNewCart(name, description, price, category,quantity){
    return function(dispatch){
        const newCartData = {
            id: 0,
            name: name,
            description: description,
            price: price,
            isOutOfStock: false,
            category: category,
            quantity:quantity
        };

        cartApi
            .save(newCartData)
            .then(newCart => {
                const action = { type: "ADD_CART", payload: newCart };
                dispatch(action);
            })
    };
    
}

export default addNewCart;