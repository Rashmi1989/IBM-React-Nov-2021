import cartApi from '../Products/services/cartApi';

function loadCart(){
    return function(dispatch){
        cartApi
            .getAll()
            .then(function(cartItems){
                const action = { type: "INIT_CARTS", payload: cartItems };
                dispatch(action);
            });
    }
}

export default loadCart;