import addNewCart from '../addNewCart';
import removeCart from '../removeFromCart';
//import toggleOutOfStock from './toggleOutOfStock';
//import removeOutOfStock from './removeOutOfStock';
import loadCart from '../loadCart';

const actionCreators = { 
    //addNewCart, removeCart, updateCart ,loadCart
    addNewCart, removeCart ,loadCart

};

export default actionCreators;