import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import CartList from './CartList'
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import cartActionCreators from '../actions/cartIndex'

class Cart extends Component{

     render(){
      const {data,addNewCart,removeCart,loadCart} = this.props;
      console.log('value of load inside cart.jsx',data.cartItems);
        return(

             <div> 
                 <input type = 'button' value='Load Cart' onClick={loadCart}/>
                 <br/>
                 <br/>
                 Welcome to your cart
                 <section className="list">
                <ol>
                    Your cart items:
                    <CartList cartList={data.cartItems}/>
                </ol>
            </section>
             </div>


        )

     }

}

function mapStateToProps(storeState){
  
    console.log('inside mapStatetoprops cart index.js',storeState);
     return { data: storeState};
 
 }
 
 
 function mapDispatchToProps(dispatch) {
     console.log('we are here mapDispatchToProps cart index.js',dispatch);
     return bindActionCreators(cartActionCreators,dispatch);
 }

 export default connect(mapStateToProps, mapDispatchToProps)(Cart);