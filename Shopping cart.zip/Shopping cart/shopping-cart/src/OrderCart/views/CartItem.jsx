import React, { Component } from 'react';


const CartItem = (props) => {
    const {cartItem,removeCart } = props;
    console.log('inside cartitem.jsx props',removeCart);
    return (
        <li>
            <span className='cart'>
                {cartItem.name}
            </span>
            <span>{cartItem.category} </span>
            <div>{cartItem.description}</div>
            <div className="price">{cartItem.price}</div>
            <input type='button' value='+'/>
            <input type='button' value='-'/>
            <br />
            <input type='button' value='Remove from cart' onClick={() => removeCart(cartItem)}/>
        </li>
    )
}


export default CartItem;