import React, { Component } from 'react';


const CartItem = (props) => {
    const {cartItem } = props;
    console.log('inside cartitem.jsx props',cartItem);
    return (
        <li>
            <span className='cart'>
                {cartItem.name}
            </span>
            <span>{cartItem.category} </span>
            <div>{cartItem.description}</div>
            <div className="price">{cartItem.price}</div>
            <input type='button' value='+'/>
            <input type='button' value='-'/>
            <br />
            <input type='button' value='Remove from cart'/>
        </li>
    )
}


export default CartItem;