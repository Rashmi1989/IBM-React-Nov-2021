
import React, { Component } from 'react';
import CartItem from './CartItem';
//import './productsList.css';

class CartList extends Component {
    render() {
        const {cartList,removeCart} = this.props;
        console.log('inside cartList.jsx render',this.props);
        
        const CartItems = cartList.map(cartItem => (
            <CartItem
               cartItem = {cartItem}
               key={cartItem.id}
               removeCart={removeCart}
            />
        )

        );
        return (
            <div className='center-col'>

               <section className="list">
                <ol>
                  {CartItems}
                </ol>
            </section>
            </div>
            
        )
    }
}

export default CartList;

/*
import React, { Component } from 'react';
import CartItem from './CartItem';
//import './productsList.css';

class CartList extends Component {
    render() {
        return (
           <div>
              Cartlist:
           </div>
        )
    }
}

export default CartList;
*/