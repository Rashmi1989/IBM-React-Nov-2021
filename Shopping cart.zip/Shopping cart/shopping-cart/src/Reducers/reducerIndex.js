import { combineReducers } from 'redux';

import productsReducer from "./productsReducer";
import cartsReducer from "./cartReducer";

const rootReducer = combineReducers({
  products: productsReducer,
  cartItems: cartsReducer
 // categories: categoriesReducer
});

export default rootReducer;
