function cartsReducer(currentState = [], action) {
    if (action.type === 'ADD_CART') {
        const newState = [...currentState, action.payload];
        return newState;
    }

    if (action.type === 'UPDATE_CART') {
        const updatedProduct = action.payload;
        const newState = currentState.map(p => p.id === updatedProduct.id ? updatedProduct : p);
        return newState;
    }
    if (action.type === 'REMOVE_CART') {
        const newState = currentState.filter(p => p.id !== action.payload.id);
        return newState;
    }
    
    if (action.type === 'INIT_CARTS'){
        return action.payload;
    }
    return currentState;
}

export default cartsReducer;
